<?
$arModuleVersion = array(
	"VERSION" => "0.0.1",
	"VERSION_DATE" => "2018-10-28 10:54:14"
);
?>