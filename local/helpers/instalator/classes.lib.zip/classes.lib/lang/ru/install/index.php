<?
$MESS["CLASSES_LIB_MODULE_NAME"] = "classes.lib";
$MESS["CLASSES_LIB_MODULE_DESC"] = "Атолоад классов";
$MESS["CLASSES_LIB_PARTNER_NAME"] = "andreyankuse";
$MESS["CLASSES_LIB_PARTNER_URI"] = "http://nashy.by";

$MESS["CLASSES_LIB_INSTALL"] = "Установка модуля \"classes.lib\"";
$MESS["CLASSES_LIB_UNINSTALL"] = "Деинсталяция модуля \"classes.lib\"";

$MESS["CLASSES_LIB_INSTALL_ERROR_VERSION"] = "Версия главного модуля ниже 14. Не поддерживается технология D7. Пожалуйста обновите систему.";

$MESS["CLASSES_LIB_IBLOCK_TYPE_NAME_EN"] = "classes.lib";
$MESS["CLASSES_LIB_IBLOCK_TYPE_NAME_RU"] = "classes.lib";
$MESS["CLASSES_LIB_IBLOCK_TYPE_ALREADY_EXISTS"] = "Такой тип инфоблока уже существует";
$MESS["CLASSES_LIB_IBLOCK_ALREADY_EXISTS"] = "Инфоблок с таким кодом уже существует";
$MESS["CLASSES_LIB_IBLOCK_TYPE_DELETION_ERROR"] = "Ошибка удаления типа инфоблока";
?>